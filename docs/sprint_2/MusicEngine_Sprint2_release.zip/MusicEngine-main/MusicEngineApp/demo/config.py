from django.apps import AppConfig


class MyConfig(AppConfig):
    name = 'MusicEngineApp.demo'
    label = 'demo'
