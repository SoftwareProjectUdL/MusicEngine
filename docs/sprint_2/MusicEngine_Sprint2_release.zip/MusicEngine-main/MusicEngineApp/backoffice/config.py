from django.apps import AppConfig


class MyConfig(AppConfig):
    name = 'MusicEngineApp.backoffice'
    label = 'backoffice'
