# Daily Meeting: 23-03-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Problems/Difficulties

| Problem | Task | Owner | Description |
|---------|------|-------|-------------|
| __      | __   | __    | __          |

## Actions

| Type | Description                    | Owner          | Deadline   |
|------|--------------------------------|----------------|------------|
| I    | Registro y autenticación hecha | _Gerard Monsó_ |            |
| T    | Crear el modelo de datos       | _Guillem Mora_ | 26/03/2023 |

T: Task
D: Decision
I: Information