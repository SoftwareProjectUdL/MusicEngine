# Sprint Retrospective Title: 16-03-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Retrospective Overview

| Team Member      | Issue Found                                                     |  
|------------------|-----------------------------------------------------------------|
| Gerard Monsó     | Falta de informació per entendre el projecte                    |   
| Marc Bustos      | Mala organització de les tasques en funció de les especialitats |
| Hector del Egido | Arribar a les deadlines bastant justes                          |

## Restrospective Actions

| Action                        | Description                                                                                                                                                |  
|-------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Tutorial                      | En cas que es canviï l'estructura del projecte, fer una petita reunió o guia per informar de com funciona actualment                                       |   
| Autoconeixement i comunicació | Pel fet que tot el equip de treball es desconegut entre si, anirem consultant i valorant les capacitats de cadascun en funció de les tasques corresponents |
| Comunicació i organització    | Com anteriorment, mentres anem desenvolupant el project amb l'equip, comunicar disponibilitat, capacitat i informar cualsevol problema amb immediatesa     |

## Next Sprint Team Organization

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |
