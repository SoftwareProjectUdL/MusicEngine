# Índice

### Daily Meetings

##### Plantilla

- [DailyMeetingsTemplate.md](../DailyMeetingsTemplate.md)

##### Sprint 1

- [DailyMeeting16-03-23.md](./DailyMeeting16-03-23.md)
- [DailyMeeting21-03-23.md](./DailyMeeting21-03-23.md)
- [DailyMeeting23-03-23.md](./DailyMeeting23-03-23.md)
- [DailyMeeting28-03-23.md](./DailyMeeting28-03-23.md)
- [DailyMeeting30-03-23.md](./DailyMeeting30-03-23.md)

### Retrospective Meetings

##### Plantilla

- [RetrospectiveMeetingTemplate.md](../RetrospectiveMeetingTemplate.md)

##### Sprint 1

- [RetrospectiveMeeting16-03-23.md](./RetrospectiveMeeting16-03-23.md)

### Review Meetings

##### Plantilla

- [ReviewMeetingTemplate.md](../ReviewMeetingTemplate.md)

##### Sprint 1

- [ReviewMeeting16-03-23.md](./ReviewMeeting16-03-23.md)

### Sprint Planning Meetings

##### Plantilla

- [SprintPlanningMeetingTemplate.md](../SprintPlanningMeetingTemplate.md)

##### Sprint 1

- [SprintPlanningMeeting16-03-23.md](./SprintPlanningMeeting16-03-23.md)