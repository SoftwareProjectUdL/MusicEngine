# Daily Meeting: 02-05-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Problems/Difficulties

| Problem | Task | Owner | Description |
|---------|------|-------|-------------|
| __      | __   | __    | __          |

## Actions

| Type | Description                                                | Owner          | Deadline   |
|------|------------------------------------------------------------|----------------|------------|
| T    | Crear la pàgina de les hores treballades per part del tècnic especialista. | _Gerard Monsó_ | 09/05/2023 |
| T    | Implementar l'accés als materials amb el seu estat i quantitat. | _Gerard Monsó_ | 09/05/2023 |

T: Task
D: Decision
I: Information
