# Daily Meeting: 20-04-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Problems/Difficulties

| Problem | Task | Owner | Description |
|---------|------|-------|-------------|
| __      | __   | __    | __          |

## Actions

| Type | Description                                                | Owner          | Deadline   |
|------|------------------------------------------------------------|----------------|------------|
| T    | Configurar el sistema d'autenticació departament comercial | _Guillem Mora_ | 23/04/2023 |

T: Task
D: Decision
I: Information
