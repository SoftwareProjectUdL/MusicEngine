# Daily Meeting: 13-04-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Problems/Difficulties

| Problem                                         | Task | Owner              | Description                                                                             |
|-------------------------------------------------|------|--------------------|-----------------------------------------------------------------------------------------|
| _Plantejament de les user stories dels tècnics_ | __   | _Hector del Egido_ | _L'ordre de les iteracions han sigut primer departament comercial i tot seguit tècnics_ |

## Actions

| Type | Description                                    | Owner              | Deadline   |
|------|------------------------------------------------|--------------------|------------|
| T    | Implementació de les user stories dels tècnics | _Hector del Egido_ | 18/04/2023 |
| T    | Implementació de les user stories dels tècnics | _Marc Bustos_      | 18/04/2023 |
| T    | Implementació de les user stories dels tècnics | _Joel Rozado_      | 18/04/2023 |

T: Task
D: Decision
I: Information