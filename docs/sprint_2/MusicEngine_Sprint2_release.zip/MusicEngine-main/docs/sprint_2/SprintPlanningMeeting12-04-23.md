# Sprint Planing Title: 12-04-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Spring Planing Overview

*Here you need to include a picture of the Spring Planning in the model Kanban*

![Kanban](./Kanban.png)

Considering the proposed distribution in the model Kanban, the overall activities to be performed by the team are:

| Team Member | Overall Task Description          |  
|-------------|-----------------------------------|
| Developers  | Registre i autenticació           |
| Developers  | Gestió de reserves de sales       |
| Developers  | Gestió de tècnics o especialistes |
| Developers  | Material reserva                  |
| Developers  | Hores tècnics o especialistes     |