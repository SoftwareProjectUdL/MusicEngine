# Daily Meeting: 25-04-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Problems/Difficulties

| Problem | Task | Owner | Description |
|---------|------|-------|-------------|
| __      | __   | __    | __          |

## Actions

| Type | Description                                                | Owner          | Deadline   |
|------|------------------------------------------------------------|----------------|------------|
| D    | Establir quines mesures de seguretat per assegurar que només els usuaris autoritzats tinguin accés al sistema. | _Guillem Mora_ | 26/04/2023 |
| T    | Implementar les mesures de seguretat per assegurar que només els usuaris autoritzats tinguin accés al sistema. | _Gerard Monsó_ | 27/04/2023 |

T: Task
D: Decision
I: Information
