# Daily Meeting: 27-04-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Problems/Difficulties

| Problem | Task | Owner | Description |
|---------|------|-------|-------------|
| __      | __   | __    | __          |

## Actions

| Type | Description                                                | Owner          | Deadline   |
|------|------------------------------------------------------------|----------------|------------|
| T    | Implementar la capacitat de bsucar factures existents per número de factura o per nom del client. | _Gerard Monsó_ | 02/05/2023 |
| T    | Crear la pàgina de creació de factures, incloent la validació de dades i la creació de registres en la base de dades. | _Gerard Monsó_ | 02/05/2023 |
| T    | Afegir la funcionalitat de modificació de factures existents per als usuaris del departament Comercial i de Facturció. | _Gerard Monsó_ | 02/05/2023 |


T: Task
D: Decision
I: Information
