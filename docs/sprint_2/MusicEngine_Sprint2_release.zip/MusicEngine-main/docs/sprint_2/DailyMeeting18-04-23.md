# Daily Meeting: 18-04-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Problems/Difficulties

| Problem                                    | Task | Owner          | Description                                                                 |
|--------------------------------------------|------|----------------|-----------------------------------------------------------------------------|
| _Dubte amb els danys de materials i sales_ | __   | _Requirements_ | _Requerim d'enviar un correu al departament de gestió per saber informació_ |

## Actions

| Type | Description                                                | Owner          | Deadline   |
|------|------------------------------------------------------------|----------------|------------|
| T    | Configurar el sistema d'autenticació departament comercial | _Guillem Mora_ | 23/04/2023 |
| T    | Implementació vista departament comercial                  | _Gerard Monsó_ | 23/04/2023 |

T: Task
D: Decision
I: Information