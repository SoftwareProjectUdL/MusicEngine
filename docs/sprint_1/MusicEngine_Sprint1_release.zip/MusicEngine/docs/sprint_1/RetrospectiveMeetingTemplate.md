# Sprint Retrospective Title: YY-MM-YYYY

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Retrospective Overview

| Team Member | Issue Found                                                            |  
|-------------|------------------------------------------------------------------------|
| XXXXX       | Description of the identified issue in the team/management/development |   
| XXXXX       | Description of the identified issue in the team/management/development |  
| XXXXX       | Description of the identified issue in the team/management/development |

## Restrospective Actions

| Action   | Description                                                 |  
|----------|-------------------------------------------------------------|
| Action 1 | Description of the action to overcome the identified issues |   
| Action 2 | Description of the action to overcome the identified issues |  
| Action 3 | Description of the action to overcome the identified issues |

## Next Sprint Team Organization

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |