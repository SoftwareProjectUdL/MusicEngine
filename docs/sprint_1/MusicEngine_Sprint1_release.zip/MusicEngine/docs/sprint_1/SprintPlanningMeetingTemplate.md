# Sprint Planing Title: YY-MM-YYYY

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |


## Spring Planing Overview

*Here you need to include a picture of the Spring Planning in the model Kanban*

Considering the proposed distribution in the model Kanban, the overall activities to be performed by the team are:

| Team Member | Overall Task Description |  
|-------------|--------------------------|
| XXXXX       | Task Description         |   
| XXXXX       | Task Description         |  
| XXXXX       | Task Description         |  