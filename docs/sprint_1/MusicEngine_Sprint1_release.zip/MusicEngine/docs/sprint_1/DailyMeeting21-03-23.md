# Daily Meeting: 21-03-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Problems/Difficulties

| Problem | Task | Owner | Description |
|---------|------|-------|-------------|
| __      | __   | __    | __          |

## Actions

| Type | Description                 | Owner          | Deadline   |
|------|-----------------------------|----------------|------------|
| I    | Template del proyecto hecha | _Gerard Monsó_ |            |
| T    | Registro y autenticación    | _Gerard Monsó_ | 26/03/2023 |

T: Task
D: Decision
I: Information