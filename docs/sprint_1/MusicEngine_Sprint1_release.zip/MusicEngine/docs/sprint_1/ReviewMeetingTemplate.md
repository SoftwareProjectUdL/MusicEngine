# Sprint Review Title: DD-MM-YYYY

## Work Scheduled/Performed

| Action                 | Brief Description | Completed |
|------------------------|-------------------|-----------|
| Overall Action 1 Title | Task Description  | [Yes/No]  |
| Overall Action 2 Title | Task Description  | [Yes/No]  |
| Overall Action 3 Title | Task Description  | [Yes/No]  |

## Burn-down Graph

*Here we need an image reflecting the advances in the Burn-down graph. Complementing the image, we need a small
paragraph describing the Scrum Master opinion about the advances.*

[IMAGE GOES HERE]

[DESCRIPTION GOES HERE]

## Brun-up (Velocity) Graph

*Here we need an image reflecting the advances in the Burn-up graph. Complementing the image, we need a small paragraph
describing the Scrum Master opinion about the advances.*

[IMAGE GOES HERE]

[DESCRIPTION GOES HERE]

## Client Improvements

For the conclusions we need to reflect improvement points reflected by our customer.

| Client Improvement           | Description      |  
|------------------------------|------------------|
| Client Improvement Action 1  | Task Description |  
| Client Improvement Action 2  | Task Description | 
| Client Improvement Action 3  | Task Description | 