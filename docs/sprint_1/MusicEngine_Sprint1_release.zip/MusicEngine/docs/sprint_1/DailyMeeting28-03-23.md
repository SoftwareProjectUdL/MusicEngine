# Daily Meeting: 28-03-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Problems/Difficulties

| Problem                  | Task                           | Owner          | Description                                              |
|--------------------------|--------------------------------|----------------|----------------------------------------------------------|
| _Estructura de proyecto_ | _Gestión de reservas de salas_ | _Guillem Mora_ | _Problemas de comprensión de la estructura del proyecto_ |

## Actions

| Type | Description                    | Owner          | Deadline   |
|------|--------------------------------|----------------|------------|
| I    | Crear el modelo de datos hecho | _Guillem Mora_ |            |
| T    | Lista de reservas              | _Guillem Mora_ | 02/04/2023 |

T: Task
D: Decision
I: Information