# Daily Meeting: DD-MM-YYYY

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Problems/Difficulties

| Problem | Task | Owner | Description |
|---------|------|-------|-------------|
| __      | __   | __    | __          |

## Actions

| Type | Description | Owner | Deadline   |
|------|-------------|-------|------------|
|      |             | __    | DD/MM/YYYY |

T: Task
D: Decision
I: Information