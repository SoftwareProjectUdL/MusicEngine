# Daily Meeting: 16-03-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Problems/Difficulties

| Problem | Task | Owner | Description |
|---------|------|-------|-------------|
| __      | __   | __    | __          |

## Actions

| Type | Description                     | Owner          | Deadline   |
|------|---------------------------------|----------------|------------|
| T    | Estructura inicial del proyecto | _Gerard Monsó_ | 22/03/2023 |

T: Task
D: Decision
I: Information