# Daily Meeting: 11-04-2023

| Assistant | Role             |  
|-----------|------------------|
| XXX       | Developers       |   
| XX        | Requirements     |  
| XX        | Quality          |
| XX        | Project Managers |

## Problems/Difficulties

| Problem                  | Task                           | Owner          | Description                                              |
|--------------------------|--------------------------------|----------------|----------------------------------------------------------|
| _Estructura de proyecto_ | _Gestión de reservas de salas_ | _Guillem Mora_ | _Problemas de comprensión de la estructura del proyecto_ |
| _Lista reservas_         | _Gestión de reservas de salas_ | _Guillem Mora_ | _Verificación de la implementación este correcta_        |

## Actions

| Type | Description                    | Owner          | Deadline |
|------|--------------------------------|----------------|----------|
| I    | Explicación breve del proyecto | _Gerard Monsó_ |          |
| I    | Lista de reservas hecha        | _Guillem Mora_ |          |

T: Task
D: Decision
I: Information